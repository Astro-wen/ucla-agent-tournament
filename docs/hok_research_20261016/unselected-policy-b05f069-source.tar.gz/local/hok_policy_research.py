"""Pre-registered, offline-only HoK hypotheses; no scoring engine or deployed policy selection.

Sources: docs/hok_sources_1016.md at 53ead14, especially sections 2, 5, 6, 7 and 9.
The platform promises walk-home, not healing; target macros do not promise arbitrary targeting,
cast durations, tower ranges, or safe travel. Every number below is a declared experimental
threshold, not a claim about Tencent mechanics. No opponent metadata is inspected.

Usage:
    python -m local.hok_policy_research --json
    policy = make_policy("observed_damage_v1")
    action, tag = policy.decide(raw)
    policy.on_result(result)

All factories use a per-instance observed game clock by default. An optional ``clock`` argument
can supply the inherited scheduler/transport clock for an evaluator, but strategy timers always
use state_version * 0.2 game seconds. No wall-clock fallback fabricates progress when it is absent.
"""

from __future__ import annotations

import argparse
from collections import deque
from dataclasses import asdict, dataclass, field
from functools import partial
import hashlib
import json
import math
from types import MappingProxyType
from typing import Any, Callable

from agent.hok import policy as hok

REGISTRATION = "hok-policy-research-20261016-v1"
BASELINE_COMMIT = "1b31f6d"
DEVELOPMENT_SEEDS = (1101, 1102)
SELECTION_SEEDS = (1201,)
RESERVED_SEEDS = (8101, 8102)  # declared only; this module never runs or selects any seed
GAME_SECONDS_PER_STEP = 0.2  # platform contract, NOT wall-clock step_interval_s
HISTORY_SECONDS = 2.0


@dataclass(frozen=True)
class Profile:
    name: str
    mechanism: str
    parameters: tuple[tuple[str, float], ...] = ()
    risk: str = ""


# Frozen before any strength comparison. Names identify our own hypotheses, never opponents.
PROFILES = MappingProxyType({
    "baseline": Profile("baseline", "Unchanged 1b31f6d rules, with an observed game clock."),
    "objective_guarded_v1": Profile(
        "objective_guarded_v1",
        "Prefer advance over a hero fight only when a visible enemy building is nearer than the labelled hero, "
        "our HP is high and observed steady, and no visible crystal threat or severe local disadvantage exists.",
        (("minimum_hp", 0.65),),
        "Walking toward a building does not guarantee a hit; unseen enemies and target priority remain unknown."),
    "observed_damage_v1": Profile(
        "observed_damage_v1",
        "Replace proximity-only tower retreat with a recent observed HP loss or visible severe disadvantage. "
        "Keep the baseline critical-HP and recovery hysteresis.",
        (("observed_loss_fraction", 0.06),),
        "Waiting for observed damage can react late; visible numerical advantage is not proof of safety."),
    "bounded_recovery_v1": Profile(
        "bounded_recovery_v1",
        "If an actual retreat produces no HP gain, briefly try a legal productive macro after a stationary "
        "plateau or a capped retreat; fresh damage or visible severe disadvantage cancels the probe.",
        (("minimum_retreat_s", 10.0), ("no_gain_s", 8.0), ("stationary_s", 4.0),
         ("retreat_cap_s", 30.0), ("probe_s", 4.0)),
        "Leaving with low HP is risky. The cap is a bounded anti-idle experiment, not a travel/healing estimate."),
    "late_objective_v1": Profile(
        "late_objective_v1",
        "Near a declared step/time limit, take an already offered structure attack instead of continuing "
        "recovery if HP is adequate and observed steady and no visible severe danger is present.",
        (("window_s", 12.0), ("minimum_hp", 0.55)),
        "Does not predict return speed, future healing, damage, or whether a hit finishes the structure."),
    "skill_residency_v1": Profile(
        "skill_residency_v1",
        "Retain a just-issued, still-offered skill for a short game-time residency before another offensive "
        "macro can replace it; retreat and unavailable skills override immediately.",
        (("residency_s", 0.4),),
        "This is NOT a cast-duration estimate. It may delay a better attack or repeat a skill macro."),
})


class ObservedGameClock:
    """Monotone, per-match game time; repeated/stale views cannot age strategy timers."""

    def __init__(self) -> None:
        self.now = 0.0
        self.version: int | None = None

    def __call__(self) -> float:
        return self.now

    def observe(self, raw: Any) -> bool:
        version = hok._small_int(raw.get("state_version"), 0, 2 ** 63 - 1) if isinstance(raw, dict) else None
        if version is None or (self.version is not None and version < self.version):
            return False
        self.version = version
        self.now = version * GAME_SECONDS_PER_STEP
        return True


@dataclass
class HeroEvidence:
    hp: float | None = None
    maximum: float | None = None
    first_seen: float | None = None
    last_seen: float | None = None
    last_damage: float | None = None
    last_gain: float | None = None
    position: tuple[float, float] | None = None
    stationary_since: float | None = None
    deaths: int | None = None
    known: bool = False
    losses: deque = field(default_factory=lambda: deque(maxlen=16))

    def sample(self, me: dict, now: float) -> bool:
        """Own HP history only; returns True on observed death or a new life."""
        hp, maximum = hok._num(me.get("hp")), hok._num(me.get("max_hp"))
        deaths = hok._small_int(me.get("deaths"), 0, 999999)
        dead = hp is not None and hp <= 0
        changed_life = dead or (self.hp is not None and self.hp <= 0 and hp is not None and hp > 0) \
            or (deaths is not None and self.deaths is not None and deaths > self.deaths)
        known = hp is not None and maximum is not None and maximum > 0 and 0 < hp <= maximum
        comparable = self.known and known and not changed_life and self.maximum == maximum
        reset = changed_life or self.maximum != maximum \
            or (self.last_seen is not None and now - self.last_seen > HISTORY_SECONDS)
        if reset:
            self.first_seen = None
            self.last_damage = None
            self.last_gain = None
            self.losses.clear()
            self.stationary_since = None
        if known:
            if self.first_seen is None:
                self.first_seen = now
            if self.last_gain is None:
                self.last_gain = now  # initial observation anchor, not evidence that healing occurred
            if comparable and self.hp is not None:
                if hp < self.hp:
                    # A gap destroys a "steady HP" interval, not the newly observed net loss.
                    # Timestamp the observation, without claiming when the actual damage happened.
                    self.last_damage = now
                    self.losses.append((now, (self.hp - hp) / maximum))
                elif hp > self.hp:
                    self.last_gain = now
            self.last_seen = now
        else:
            self.first_seen = None  # a missing HP observation is not evidence of a safe/stable interval
        p = hok._pos(me)
        if p is None:
            self.stationary_since = None
        elif self.stationary_since is None or p != self.position:
            self.stationary_since = now
        self.position = p
        self.hp, self.maximum, self.known = hp, maximum, known
        if deaths is not None:
            self.deaths = deaths
        while self.losses and now - self.losses[0][0] > HISTORY_SECONDS:
            self.losses.popleft()
        return changed_life

    def stable(self, now: float) -> bool:
        return self.known and self.first_seen is not None and now - self.first_seen >= HISTORY_SECONDS \
            and (self.last_damage is None or now - self.last_damage >= HISTORY_SECONDS)

    def observed_loss(self, now: float) -> float:
        return sum(loss for when, loss in self.losses if now - when <= HISTORY_SECONDS)


@dataclass
class RecoveryEpisode:
    started: float
    probe_started: float | None = None
    probe_until: float | None = None


@dataclass(frozen=True)
class Frame:
    standing: dict[int, str] = field(default_factory=dict)
    buildings: tuple[tuple[int, str, tuple[float, float]], ...] = ()
    step_seconds_left: float | None = None
    wall_seconds_left: float | None = None


class ResearchPolicy(hok.HokPolicy):
    """An offline rule hook plus own-observation history, reusing the complete production safety/scheduler."""

    def __init__(self, profile: Profile, *, clock: Callable[[], float] | None = None) -> None:
        self.profile = profile
        self.parameters = dict(profile.parameters)
        self.game_clock = ObservedGameClock()
        super().__init__(clock=self.game_clock if clock is None else clock)
        self.evidence: dict[int, HeroEvidence] = {}
        self.recovery: dict[int, RecoveryEpisode] = {}
        self.skill_started: dict[int, tuple[str, float]] = {}
        self.frame = Frame()
        self._last_output: tuple[int, str, float] | None = None

    def decide(self, raw: dict):
        fresh = self.game_clock.observe(raw)
        self._observe(raw, fresh)
        self._last_output = None
        result = super().decide(raw)
        action = result[0]
        if isinstance(action, str):
            match = hok._SEAT_ID.fullmatch(action)
            if match and match[2] in hok.MACROS:
                seat, macro = int(match[1]), match[2]
                now = self.game_clock()
                self._last_output = (seat, macro, now)
                if macro.startswith("macro_skill"):
                    self.skill_started[seat] = (macro, now)
                else:
                    self.skill_started.pop(seat, None)
        return result

    def on_result(self, result) -> None:
        sent = self._last_output
        super().on_result(result)
        if sent is not None and isinstance(result, dict):
            seat, macro, when = sent
            if result.get("error"):
                self.skill_started.pop(seat, None)
            elif macro == "macro_retreat" and self.profile.name == "bounded_recovery_v1":
                self.recovery.setdefault(seat, RecoveryEpisode(when))
        self._last_output = None

    def _observe(self, raw: Any, fresh: bool) -> None:
        if not isinstance(raw, dict):
            self.frame = Frame()
            return
        now = self.game_clock()
        buildings = set()
        for seat in hok._seat_list(raw):
            summary = hok.summary_of(raw, seat)
            me = summary.get("my_hero") if isinstance(summary.get("my_hero"), dict) else {}
            evidence = self.evidence.setdefault(seat, HeroEvidence())
            if fresh:
                if evidence.sample(me, now):
                    self.recovery.pop(seat, None)
                    self.skill_started.pop(seat, None)
            else:
                evidence.known = False  # no strategy timing claims from missing/stale versions
                evidence.first_seen = None
                evidence.stationary_since = None
            for building in hok._dict_list(summary.get("structures")):
                camp, p = hok._camp(building.get("camp")), hok._pos(building)
                kind, hp = building.get("type"), hok._num(building.get("hp"))
                if camp is not None and p is not None and hp is not None and hp > 0 \
                        and building.get("visible") is not False and isinstance(kind, str):
                    kind = kind[:64].upper()
                    if "TOWER" in kind or "CRYSTAL" in kind:
                        buildings.add((camp, kind, p))
        maximum = hok._small_int(raw.get("max_steps"), 1, 2 ** 63 - 1)
        version = hok._small_int(raw.get("state_version"), 0, 2 ** 63 - 1)
        step_left = GAME_SECONDS_PER_STEP * max(0, maximum - version) \
            if maximum is not None and version is not None else None
        wall_left = hok._num(raw.get("seconds_left"))
        if wall_left is not None and wall_left < 0:
            wall_left = None
        self.frame = Frame(hok.standing_orders(raw), tuple(sorted(buildings)), step_left, wall_left)

    @staticmethod
    def _outnumbered(summary: dict, team: hok.Team) -> bool:
        me = summary.get("my_hero") if isinstance(summary.get("my_hero"), dict) else {}
        p = hok._pos(me)
        return p is not None and team.outnumbered(p)

    def _crystal_threat(self, team: hok.Team) -> bool:
        # NEAR is only the baseline's local-proximity heuristic, not a claimed weapon range.
        return any(camp == team.camp and "CRYSTAL" in kind
                   and any(hok._dist(p, enemy) <= hok.NEAR for enemy in team.enemies.values())
                   for camp, kind, p in self.frame.buildings)

    def _choose_macro(self, seat: int, summary: dict, macros: dict[str, str], team: hok.Team,
                      retreating: bool) -> str | None:
        baseline = super()._choose_macro(seat, summary, macros, team, retreating)
        name = self.profile.name
        if name == "baseline" or not macros or baseline is None:
            return baseline
        me = summary.get("my_hero") if isinstance(summary.get("my_hero"), dict) else {}
        share, p = hok.hp_share(me), hok._pos(me)
        evidence = self.evidence.get(seat)
        now = self.game_clock()
        outnumbered = self._outnumbered(summary, team)

        if name == "observed_damage_v1":
            if "macro_retreat" in macros:
                if (share is not None and share < hok.LOW_HP) \
                        or (retreating and (share is None or share < hok.HEALED)):
                    return "macro_retreat"
                loss = evidence.observed_loss(now) if evidence is not None and evidence.known else 0.0
                if share is not None and share < hok.HURT \
                        and (outnumbered or loss >= self.parameters["observed_loss_fraction"]):
                    return "macro_retreat"
            # Deliberately omit proximity-only tower danger, not the baseline legal combat selection.
            return hok.rule_macro(summary, macros, team=None, retreating=False)

        if name == "bounded_recovery_v1":
            return self._bounded_recovery(seat, summary, macros, baseline, share, evidence, outnumbered)

        if name == "skill_residency_v1":
            active = self.skill_started.get(seat)
            if baseline != "macro_retreat" and active is not None and active[0] in macros \
                    and now - active[1] < self.parameters["residency_s"]:
                return active[0]
            return baseline

        stable = evidence is not None and evidence.stable(now)
        if name == "late_objective_v1":
            close = any(left is not None and left <= self.parameters["window_s"]
                        for left in (self.frame.step_seconds_left, self.frame.wall_seconds_left))
            if close and share is not None and share >= self.parameters["minimum_hp"] and stable \
                    and team.camp is not None and not outnumbered and not self._crystal_threat(team) \
                    and "macro_attack" in macros and hok.target_kind(macros["macro_attack"]) == "structure":
                return "macro_attack"  # already offered; no prediction of return time or future objective damage
            return baseline

        if name == "objective_guarded_v1" and baseline != "macro_retreat" \
                and share is not None and share >= self.parameters["minimum_hp"] and stable \
                and p is not None and team.camp is not None and "macro_advance" in macros \
                and not outnumbered and not self._crystal_threat(team):
            hero_distance = min((hok.distance_of(label) for macro, label in macros.items()
                                 if macro in ("macro_attack", "macro_skill1", "macro_skill2", "macro_skill3")
                                 and hok.target_is_hero(label)), default=math.inf)
            objective_distance = min((hok._dist(p, q) for camp, _, q in self.frame.buildings
                                      if camp != team.camp), default=math.inf)
            if math.isfinite(hero_distance) and objective_distance < hero_distance:
                if "macro_attack" not in macros or hok.target_kind(macros["macro_attack"]) != "structure":
                    return "macro_advance"
        return baseline

    def _bounded_recovery(self, seat: int, summary: dict, macros: dict[str, str], baseline: str,
                          share: float | None, evidence: HeroEvidence | None, outnumbered: bool) -> str:
        now = self.game_clock()
        if share is not None and share >= hok.HEALED:
            self.recovery.pop(seat, None)
            return baseline
        if self.frame.standing.get(seat) == "macro_retreat":
            self.recovery.setdefault(seat, RecoveryEpisode(now))
        episode = self.recovery.get(seat)
        if episode is None or evidence is None or share is None or not evidence.known:
            return baseline
        if episode.probe_until is not None:
            damaged = evidence.last_damage is not None and evidence.last_damage >= episode.probe_started
            if damaged or outnumbered:
                self.recovery[seat] = RecoveryEpisode(now)
                return "macro_retreat" if "macro_retreat" in macros else baseline
            if now < episode.probe_until:
                return hok.rule_macro({}, macros) or baseline  # explicit combat-only choice, never fabricated HP
            self.recovery[seat] = RecoveryEpisode(now)
            return baseline
        elapsed = now - episode.started
        no_gain = evidence.last_gain is not None and now - evidence.last_gain >= self.parameters["no_gain_s"]
        stationary = evidence.stationary_since is not None \
            and now - evidence.stationary_since >= self.parameters["stationary_s"]
        stale_recovery = elapsed >= self.parameters["retreat_cap_s"] \
            or (elapsed >= self.parameters["minimum_retreat_s"] and stationary)
        productive = hok.rule_macro({}, macros)
        if no_gain and stale_recovery and evidence.stable(now) and not outnumbered \
                and productive not in (None, "macro_retreat"):
            episode.probe_started = now
            episode.probe_until = now + self.parameters["probe_s"]
            return productive
        return baseline


def make_policy(profile: str = "baseline", *, clock: Callable[[], float] | None = None) -> ResearchPolicy:
    """A new, independent match policy. Selection is explicit and never reads an opponent or raw profile field."""
    if profile not in PROFILES:
        raise ValueError(f"Unknown research profile: {profile!r}")
    return ResearchPolicy(PROFILES[profile], clock=clock)


FACTORIES = MappingProxyType({name: partial(make_policy, name) for name in PROFILES})


def registration() -> dict:
    return {
        "registration": REGISTRATION,
        "baseline_commit": BASELINE_COMMIT,
        "evidence": "Public platform contract; all strategic effects unverified on the Tencent 5v5 engine.",
        "game_seconds_per_step": GAME_SECONDS_PER_STEP,
        "history_seconds": HISTORY_SECONDS,
        "development_seeds": DEVELOPMENT_SEEDS,
        "selection_seeds": SELECTION_SEEDS,
        "reserved_seeds_do_not_run": RESERVED_SEEDS,
        "profiles": [asdict(profile) for profile in PROFILES.values()],
    }


def registration_hash() -> str:
    return hashlib.sha256(json.dumps(registration(), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="Print the fixed registration manifest; no games are run.")
    args = parser.parse_args()
    if args.json:
        print(json.dumps({**registration(), "registration_sha256": registration_hash()}, indent=2))
    else:
        print(REGISTRATION, registration_hash())
        for name, profile in PROFILES.items():
            print(f"{name}: {profile.mechanism}")


if __name__ == "__main__":
    main()
