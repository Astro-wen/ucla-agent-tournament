"""Contract/diagnostic tests only: these do not validate Tencent engine fidelity."""
from dataclasses import replace
import json
from pathlib import Path

import pytest

from local.hok_env import (Baseline, DiagnosticTelemetry, PolicyInterfaceError, adapt_policy_interface,
                           candidate_factory, candidate_revision_factory, configured_factory,
                           frozen_import_factory, opponent_factory, play_game, source_info, source_unchanged)
from local.hok_sim import (DiagnosticGame, PROFILES, SENSITIVITY_PROFILES, SENSITIVITY_REGISTRATION,
                           SENSITIVITY_REGISTRATION_SHA256, SensitivityConfig, SensitivityGame,
                           SimConfig, digest, profile_config)
from scripts.hok_eval import (ReservedSeedError, evaluate, interface_report, parser, prepare_final_plan,
                              public_archive_index)


def idle_all(game):
    for camp in (1, 2):
        for seat in game.seats(camp):
            if seat in game.pending:
                assert not game.submit(camp, f"s{seat}:button_0", game.step).get("error")


def test_five_seats_pending_and_standing():
    game = DiagnosticGame()
    raw = game.view(1)
    assert raw["seats"] == list(range(5))
    assert game.view(2)["seats"] == list(range(5, 10))
    assert not game.submit(1, "s0:macro_advance", 0).get("error")
    assert 0 not in game.view(1)["simultaneous"]["your_pending_seats"]
    assert any(a["action_id"].startswith("s0:") for a in game.view(1)["legal_actions"]["actions"])
    x = game.heroes[0].x
    game.tick()
    assert game.heroes[0].x > x
    x = game.heroes[0].x
    game.tick()
    assert game.heroes[0].x > x  # no fresh order
    assert game.view(1)["simultaneous"]["standing_orders"]["0"] == "macro_advance"
    assert not game.submit(1, "s0:button_0", 0).get("error")  # old version OK in realtime
    x = game.heroes[0].x
    game.tick()
    assert game.heroes[0].x == x
    assert "0" not in game.view(1)["simultaneous"]["standing_orders"]


def test_raw_move_is_one_shot_and_requires_legal_values():
    game = DiagnosticGame()
    assert game.submit(1, "s0:button_2", 0)["error"] == "INVALID_ACTION"
    assert game.submit(1, {"seat": 0, "which_button": 2, "move_x": 14, "move_z": 8}, 0).get("error")
    assert not game.submit(1, {"seat": 0, "which_button": 2, "move_x": 15, "move_z": 8}, 0).get("error")
    game.tick()
    x = game.heroes[0].x
    game.tick()
    assert game.heroes[0].x == x


@pytest.mark.parametrize("action", ["s5:macro_advance", "s99:button_0", "s0:macro_skill3",
                                   {"seat": True, "which_button": 0},
                                   {"seat": 0, "macro": "macro_advance", "extra": 1},
                                   {"seat": 0, "which_button": False}, [], 17])
def test_illegal_actions_are_rejected_without_mutation(action):
    game = DiagnosticGame()
    before = game.state_hash()
    assert game.submit(1, action, 0)["error"] == "INVALID_ACTION"
    assert game.state_hash() == before


def test_lockstep_versions_all_ten_seats_and_explicit_timeout():
    game = DiagnosticGame(SimConfig(mode="lockstep"))
    with pytest.raises(RuntimeError):
        game.tick()
    with pytest.raises(RuntimeError):
        game.tick(timeout=True)  # timer cannot start before a team finishes
    assert game.submit(1, "s0:button_0", None)["error"] == "STALE_STATE"
    for seat in game.seats(1):
        assert not game.submit(1, f"s{seat}:macro_advance", 0).get("error")
    game.tick(timeout=True)
    assert game.last_fallback_players == list(range(5, 10))
    assert game.submit(1, "s0:button_0", 0)["error"] == "STALE_STATE"
    idle_all(game)
    game.tick()
    assert game.step == 2


def test_hidden_heroes_never_leak_state_or_target_labels():
    game = DiagnosticGame(SimConfig(vision_range=100))
    first = game.view(1)
    for h in game.heroes.values():
        if h.camp == 2:
            h.x += 123
            h.hp -= 42
            h.kills = 10
    assert first == game.view(1)
    for entry in first["observation"]["seats"].values():
        hidden = [h for h in entry["summary"]["other_heroes"] if not h["visible"]]
        assert len(hidden) == 5
        assert all(set(h) == {"runtime_id", "hero_id", "camp", "visible"} for h in hidden)
    assert all("enemy hero" not in a["label"] for a in first["legal_actions"]["actions"])
    # Returned payloads cannot mutate engine state.
    first["observation"]["seats"]["0"]["summary"]["my_hero"]["hp"] = -10
    assert game.heroes[0].hp > 0


def test_attack_reaim_cooldown_and_simultaneous_death_respawn():
    c = SimConfig(hero_hp=100, attack_damage=200, attack_cooldown_s=1.0, respawn_s=0.4,
                  tower_damage=0, base_heal_fraction_per_s=0, clear_orders_on_death=True)
    game = DiagnosticGame(c)
    for seat in (0, 5):
        game.heroes[seat].x = 0
        game.heroes[seat].z = 0
    assert not game.submit(1, "s0:macro_attack", 0).get("error")
    assert not game.submit(2, "s5:macro_attack", 0).get("error")
    game.tick()
    assert game.heroes[0].hp == game.heroes[5].hp == 0
    assert game.kills == {1: 1, 2: 1}
    assert not game.standing
    assert [a["action_id"] for a in game._entries(0)] == ["s0:button_0"]
    game.tick()
    game.tick()
    game.tick()
    assert game.heroes[0].hp == 100
    assert game.heroes[0].x == -c.half_length
    assert game.respawns == {1: 1, 2: 1}


def test_standing_attack_reaims_and_waits_for_cooldown():
    game = DiagnosticGame(SimConfig(tower_damage=0, attack_damage=100, attack_cooldown_s=0.4))
    for seat, x in ((0, 0), (5, 1000), (6, 2000)):
        game.heroes[seat].x, game.heroes[seat].z = x, 0
    game.submit(1, "s0:macro_attack", 0)
    game.tick()
    assert game.heroes[5].hp == 3900
    assert "s0:macro_attack" not in [a["action_id"] for a in game._entries(0)]
    game.heroes[5].x = 50000
    game.tick()
    assert game.heroes[6].hp == 4000
    game.tick()
    assert game.heroes[6].hp == 3900


def test_healing_capped_and_dead_heroes_do_not_heal():
    game = DiagnosticGame(SimConfig(base_heal_fraction_per_s=1.0))
    game.heroes[0].hp = 3999
    game.heroes[1].hp, game.heroes[1].revive_at = 0, 100
    game.tick()
    assert game.heroes[0].hp == 4000
    assert game.heroes[1].hp == 0
    assert game.healed[1] == 1


@pytest.mark.parametrize("damage,kills,winner", [({1: 5, 2: 4}, {1: 0, 2: 20}, 1),
                                                ({1: 4.000000001, 2: 4}, {1: 0, 2: 20}, 1),
                                                ({1: 4, 2: 4}, {1: 0, 2: 1}, 2),
                                                ({1: 4, 2: 4}, {1: 0, 2: 0}, None)])
def test_official_scoring_priority(damage, kills, winner):
    game = DiagnosticGame(SimConfig(max_steps=1))
    game.structure_damage, game.kills = damage, kills
    game.tick()
    assert game.winner_camp == winner
    assert game.result()["termination_reason"] == "step_limit"


def test_time_limit_and_crystal_victory():
    game = DiagnosticGame(SimConfig(time_limit_s=0.2))
    game.tick()
    assert game.termination_reason == "time_limit"
    game = DiagnosticGame()
    game.structures[201].hp = 0
    game.tick()
    assert game.winner_camp == 1
    assert game.result()["platform_scores"] == {"1": 1.0, "2": 0.0}


@pytest.mark.parametrize("profile", list(PROFILES))
@pytest.mark.parametrize("mode", ["realtime", "lockstep"])
def test_varied_configs_baseline_contract_and_candidate_smoke(profile, mode):
    config = profile_config(profile, mode=mode, max_steps=8)
    factory, _ = candidate_factory(Path(__file__).resolve().parents[2])
    opponent, _ = opponent_factory("random")
    report = play_game(factory, opponent, config=config, seed=7)
    assert report["protocol_failure"] is None
    assert report["stats"]["candidate"]["invalid"] == 0
    assert report["stats"]["opponent"]["invalid"] == 0
    assert set(report["stats"]["candidate"]["accepted_by_seat"]) == set("01234")


@pytest.mark.parametrize("name", ["random", "first-legal", "push", "idle"])
def test_builtin_baselines_are_legal_and_cover_every_seat(name):
    factory, _ = opponent_factory(name)
    report = play_game(factory, factory, config=SimConfig(mode="lockstep", max_steps=4))
    assert report["protocol_failure"] is None
    assert report["stats"]["candidate"]["accepted"] == 20
    assert report["stats"]["opponent"]["accepted"] == 20


def test_random_can_choose_macros_and_idle_but_never_unfilled_move():
    bot = Baseline("random", seed=2)
    raw = DiagnosticGame().view(1)
    actions = {bot.decide(raw)[0] for _ in range(100)}
    assert {a.split(":")[1] for a in actions} == {"button_0", "macro_advance", "macro_retreat"}
    assert {a.split(":")[0] for a in actions} == {f"s{s}" for s in range(5)}
    assert Baseline("first-legal").decide(raw)[0] == "s0:button_0"
    assert Baseline("push").decide(raw)[0] == "s0:macro_advance"


def test_reproducibility_and_no_raw_decisions_in_report():
    args = parser().parse_args(["--games", "1", "--max-steps", "3", "--opponent", "push"])
    one, two = evaluate(args), evaluate(args)
    assert one["reproducibility_sha256"] == two["reproducibility_sha256"]
    assert one["harness"]["ARENA_RECORD"] == "0"
    legs = one["cells"][0]["pairs"][0]["legs"]
    assert [g["candidate_camp"] for g in legs] == [1, 2]
    serialized = json.dumps(one)
    assert '"observation"' not in serialized and '"action_id"' not in serialized and '"tag"' not in serialized


def test_lockstep_wait_is_explicit_protocol_forfeit_not_game_strength():
    class Waiter:
        def decide(self, raw):
            return None, None
    push, _ = opponent_factory("push")
    report = play_game(Waiter, push, config=SimConfig(mode="lockstep", max_steps=2))
    assert report["protocol_failure"] == {"camp": 1, "kind": "lockstep_wait"}
    assert report["result"]["termination_reason"] == "evaluation_protocol_forfeit"
    assert report["stats"]["candidate"]["invalid"] == 1


@pytest.mark.parametrize("changes", [{"mode": "fake"}, {"max_steps": 0}, {"max_steps": True},
                                     {"hero_hp": float("nan")}, {"speed": -1},
                                     {"skill_ranges": [1, 2]}, {"raw_move": 1}, {"step_s": 0},
                                     {"speed": [1, 2, 3]}, {"skill_damage": 3},
                                     {"skill_cooldowns_s": "bad"}, {"skill_ranges": [1, True, 3]}])
def test_config_rejects_invalid_assumptions(changes):
    with pytest.raises(ValueError):
        replace(SimConfig(), **changes)


def test_sdk_parses_views_and_validates_ids_legalaction_and_raw_inputs():
    from altruagent import GameState
    from altruagent.runner import _validate_decision
    game = DiagnosticGame()
    state = GameState.from_mcp_state(game.view(2))
    assert state.raw["camp"] == 2
    advance = next(a for a in state.legal_actions if a.action_id == "s5:macro_advance")
    for action in (advance, advance.action_id, {"seat": 5, "macro": "macro_advance"}):
        parsed = _validate_decision(action, state.legal_actions)
        assert parsed.action_id == advance.action_id or parsed.action == {"seat": 5, "macro": "macro_advance"}
    assert not game.submit(2, advance, 0).get("error")


def test_malformed_and_foreign_seat_errors_notify_policy_without_recording_payload():
    class Refused:
        results = []
        def decide(self, raw):
            return {"seat": 9, "macro": "macro_advance"}, "SECRET_TAG"
        def on_result(self, result):
            self.results.append(result)
    idle, _ = opponent_factory("idle")
    report = play_game(Refused, idle, config=SimConfig(max_steps=2))
    assert report["stats"]["candidate"]["invalid"] == 12
    assert report["protocol_failure"] is None  # realtime rejection is recoverable
    assert len(Refused.results) == 12
    assert all(r["error"] == "INVALID_ACTION" for r in Refused.results)
    assert "SECRET_TAG" not in json.dumps(report)
    assert "s9:macro_advance" not in json.dumps(report)


def test_stale_target_refused_against_current_offers_without_losing_standing_order():
    game = DiagnosticGame()
    game.heroes[0].x = game.heroes[5].x = 0
    game.heroes[0].z = game.heroes[5].z = 0
    assert any(a["action_id"] == "s0:macro_attack" for a in game.view(1)["legal_actions"]["actions"])
    game.heroes[5].x = game.config.half_length
    assert game.submit(1, "s0:macro_attack", 0)["error"] == "INVALID_ACTION"
    assert 0 in game.pending


def test_structure_damage_is_hp_capped_and_shielding_is_explicit_parameter():
    game = DiagnosticGame(SimConfig(attack_damage=100000, tower_damage=0, crystal_shielded=True))
    game.heroes[0].x, game.heroes[0].z = game.structures[200].x, 0
    assert game._shielded(game.structures[201])
    assert not game.submit(1, "s0:macro_attack", 0).get("error")
    game.tick()
    assert game.structures[200].hp == 0
    assert game.structure_damage[1] == game.config.tower_hp
    assert not game._shielded(game.structures[201])
    unshielded = DiagnosticGame(SimConfig(crystal_shielded=False))
    assert not unshielded._shielded(unshielded.structures[201])


def test_resignation_and_terminal_contract():
    game = DiagnosticGame()
    result = game.resign(1)
    assert result["termination_reason"] == "resignation"
    assert result["outcome"]["winner_camp"] == 2
    assert result["returns"] == {"1": -1, "2": 1}
    assert game.view(1)["legal_actions"]["actions"] == []
    assert game.submit(2, "s5:macro_advance", 0)["error"] == "INVALID_ACTION"
    with pytest.raises(RuntimeError):
        game.tick()


@pytest.mark.parametrize("profile", list(PROFILES))
def test_mirrored_same_deterministic_policy_has_no_first_camp_damage_advantage(profile):
    push, _ = opponent_factory("push")
    report = play_game(push, push, config=profile_config(profile, max_steps=150), seed=37)
    scores = report["result"]["outcome"]["score"]
    assert scores["1"] == scores["2"]
    assert report["candidate_score"] == 0.5


def test_importable_factory_and_separate_candidate_package(tmp_path):
    import os
    (tmp_path / "helper.py").write_text("ACTION = 'macro_advance'\n")
    (tmp_path / "policy.py").write_text(
        "from .helper import ACTION\n"
        "class HokPolicy:\n"
        "    def __init__(self, clock): self.clock = clock\n"
        "    def decide(self, raw):\n"
        "        if not raw['simultaneous']['your_pending_seats']: return None, None\n"
        "        seat = raw['simultaneous']['your_pending_seats'][0]\n"
        "        return {'seat': seat, 'macro': ACTION}, None\n")
    candidate, info = candidate_factory(tmp_path)
    idle, _ = opponent_factory("idle")
    report = play_game(candidate, idle, config=SimConfig(max_steps=3))
    assert report["stats"]["candidate"]["accepted"] == 15
    assert info["clock_parameter"] is True
    assert info["hash_scope"] == "hok package Python files"
    old_hash = info["source_sha256"]
    old_mtime = (tmp_path / "helper.py").stat().st_mtime_ns
    (tmp_path / "helper.py").write_text("ACTION = 'macro_retreat'\n")
    os.utime(tmp_path / "helper.py", ns=(old_mtime, old_mtime))
    updated, changed = candidate_factory(tmp_path)
    assert changed["source_sha256"] != old_hash
    next_report = play_game(updated, idle, config=SimConfig(max_steps=1))
    assert next_report["stats"]["candidate"]["action_kind_counts"] == {"macro_retreat": 5}
    assert not (tmp_path / "__pycache__").exists()


def test_policy_error_counts_do_not_include_sensitive_exception_messages():
    class Broken:
        def decide(self, raw):
            raise ValueError("DO_NOT_RECORD_RAW_DECISION")
    push, _ = opponent_factory("push")
    report = play_game(Broken, push, config=SimConfig(max_steps=2))
    assert report["stats"]["candidate"]["exceptions"] == {"ValueError": 1}
    assert report["protocol_failure"]["kind"] == "policy_exception"
    assert "DO_NOT_RECORD" not in json.dumps(report)


def test_evaluation_never_connects_to_network_or_enables_recording(monkeypatch):
    import os
    import socket
    def forbidden(*_args, **_kwargs):
        raise AssertionError("offline evaluation must never connect")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setenv("ARENA_RECORD", "1")
    candidate, _ = candidate_factory(Path(__file__).resolve().parents[2])
    push, _ = opponent_factory("push")
    report = play_game(candidate, push, config=SimConfig(max_steps=10))
    assert report["protocol_failure"] is None
    assert os.environ["ARENA_RECORD"] == "0"


def test_json_mode_override_is_honored_and_cli_override_wins(tmp_path):
    path = tmp_path / "config.json"
    path.write_text('{"mode": "lockstep", "max_steps": 2}')
    args = parser().parse_args(["--games", "1", "--config", str(path)])
    assert evaluate(args)["cells"][0]["config"]["mode"] == "lockstep"
    args.mode = "realtime"
    assert evaluate(args)["cells"][0]["config"]["mode"] == "realtime"


def test_default_standing_order_survives_death_until_a_new_raw_order():
    game = DiagnosticGame(SimConfig(hero_hp=100, tower_damage=200, respawn_s=0.2))
    game.heroes[0].x, game.heroes[0].z = game.structures[200].x, 0
    assert not game.submit(1, "s0:macro_advance", 0).get("error")
    game.tick()
    assert game.heroes[0].hp == 0
    assert game.standing[0] == "macro_advance"
    game.tick()
    game.tick()
    assert game.heroes[0].hp == 100
    assert game.heroes[0].x > -game.config.half_length  # resumed without reissuing
    assert not game.submit(1, "s0:button_0", game.step).get("error")
    assert 0 not in game.standing


def test_independently_supplied_research_factory_interface(monkeypatch):
    import sys
    import types
    calls = []
    def make_bot(name, seed=0):
        calls.append((name, seed))
        return Baseline("push", seed=seed)
    monkeypatch.setitem(sys.modules, "local.hok_opponents_research", types.SimpleNamespace(make_bot=make_bot))
    factory, info = opponent_factory("research:external-bot")
    result = play_game(factory, factory, config=SimConfig(max_steps=3), seed=1016)
    assert calls == [("external-bot", 1016), ("external-bot", 1001019)]
    assert info["name"] == "external-bot"
    assert result["protocol_failure"] is None


@pytest.mark.parametrize("action", ["s9:macro_advance", False, 17, object(),
                                   {"seat": 0, "macro": "macro_advance", "unsendable": object()}])
def test_sdk_local_validation_failures_are_fatal_even_in_realtime(action):
    class Bad:
        def decide(self, raw):
            return action, None
    push, _ = opponent_factory("push")
    result = play_game(Bad, push, config=SimConfig(max_steps=2))
    assert result["protocol_failure"] == {"camp": 1, "kind": "local_validation_error"}
    assert result["stats"]["candidate"]["local_validation_errors"] == 1
    assert result["stats"]["candidate"]["invalid"] == 1


@pytest.mark.parametrize("mode", ["realtime", "lockstep"])
def test_sdk_resign_is_a_concession_not_protocol_failure(mode):
    from altruagent import RESIGN
    class Resigner:
        def decide(self, raw):
            return RESIGN, None
    push, _ = opponent_factory("push")
    result = play_game(Resigner, push, config=SimConfig(mode=mode, max_steps=2))
    assert result["protocol_failure"] is None
    assert result["result"]["termination_reason"] == "resignation"
    assert result["stats"]["candidate"]["resignations"] == 1
    assert result["candidate_score"] == 0.0


def test_realtime_nonpending_updates_replace_fresh_order_until_tick():
    game = DiagnosticGame()
    for seat in game.seats(1):
        assert not game.submit(1, f"s{seat}:macro_advance", 0).get("error")
    raw = game.view(1)
    assert raw["simultaneous"]["your_pending_seats"] == []
    assert raw["is_current_actor"] is True
    assert {int(a["action_id"].split(":")[0][1:]) for a in raw["legal_actions"]["actions"]} == set(range(5))
    assert not game.submit(1, {"seat": 0, "macro": "macro_retreat"}, 0).get("error")
    assert game.standing[0] == "macro_retreat"
    assert not game.submit(1, "s0:button_0", 0).get("error")
    assert 0 not in game.standing
    x = game.heroes[0].x
    game.tick()
    assert game.heroes[0].x == x  # latest raw order, not the earlier advance
    assert game.heroes[1].x > x


def test_lockstep_pending_remains_authoritative_and_duplicate_order_is_refused():
    game = DiagnosticGame(SimConfig(mode="lockstep"))
    game.submit(1, "s0:macro_advance", 0)
    assert not any(a["action_id"].startswith("s0:") for a in game.view(1)["legal_actions"]["actions"])
    assert game.submit(1, "s0:macro_retreat", 0)["error"] == "INVALID_ACTION"
    assert game.standing[0] == "macro_advance"


@pytest.mark.parametrize("budget", [5, 6, 10])
@pytest.mark.parametrize("period", [1, 3])
def test_realtime_equal_budgets_advance_time_without_random_forfeit(budget, period):
    random_bot, _ = opponent_factory("research:uniform_random")
    result = play_game(random_bot, random_bot, config=SimConfig(max_steps=7),
                       calls_per_step=budget, decision_steps=period)
    assert result["protocol_failure"] is None
    assert result["steps"] == 7
    periods = len(range(0, 7, period))
    for stats in result["stats"].values():
        assert stats["reserved_decision_slots"] == periods * budget
        assert stats["calls"] == stats["accepted"] == periods * budget
        assert stats["budget_exhaustions"] == periods
        assert stats["nonpending_updates"] == periods * (budget - 5)
        assert stats["invalid"] == 0
    assert result["clock_injected"] == {"candidate": True, "opponent": True}


def test_wait_voluntarily_releases_slots_but_never_transfers_them_to_other_team():
    class Waiter:
        def __init__(self, clock):
            self.clock = clock
        def decide(self, raw):
            assert self.clock() == raw["state_version"] * 0.2
            assert not hasattr(self.clock, "__closure__")  # no closure containing full world
            return None, None
    random_bot, _ = opponent_factory("research:uniform_random")
    result = play_game(Waiter, random_bot, config=SimConfig(max_steps=4), calls_per_step=10)
    a, b = result["stats"]["candidate"], result["stats"]["opponent"]
    assert a["reserved_decision_slots"] == b["reserved_decision_slots"] == 40
    assert a["calls"] == 4 and a["unused_decision_slots"] == 36
    assert b["calls"] == 40 and b["budget_exhaustions"] == 4


def test_directory_snapshot_freezes_lazy_relative_imports_and_detects_source_edits(tmp_path):
    helper = tmp_path / "helper.py"
    helper.write_text("ACTION = 'macro_advance'\n")
    (tmp_path / "policy.py").write_text(
        "class HokPolicy:\n"
        "    def __init__(self, clock):\n"
        "        from .helper import ACTION\n"
        "        self.action = ACTION\n"
        "    def decide(self, raw):\n"
        "        return {'seat': raw['seats'][0], 'macro': self.action}, None\n")
    candidate, info = candidate_factory(tmp_path)
    helper.write_text("ACTION = 'macro_retreat'\n")
    idle, _ = opponent_factory("idle")
    result = play_game(candidate, idle, config=SimConfig(max_steps=2))
    assert result["stats"]["candidate"]["action_kind_counts"] == {"macro_advance": 12}
    assert result["stats"]["candidate"]["nonpending_updates"] == 10
    assert not source_unchanged(info)
    assert info["source_kind"] == "directory_snapshot"
    assert not (tmp_path / "__pycache__").exists()


def test_git_snapshot_reads_exact_commit_without_changing_candidate_tree():
    import subprocess
    root = Path(__file__).resolve().parents[2]
    before = (root / "agent/hok/policy.py").read_bytes()
    factory, info = candidate_revision_factory(root, "HEAD")
    resolved = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
    assert info["git_commit"] == resolved
    assert info["source_kind"] == "git_snapshot"
    assert source_unchanged(info)
    push, _ = opponent_factory("push")
    result = play_game(factory, push, config=SimConfig(max_steps=3))
    assert result["clock_injected"] == {"candidate": True, "opponent": True}
    assert result["protocol_failure"] is None
    assert (root / "agent/hok/policy.py").read_bytes() == before


def test_mode_changes_no_other_physics_parameters_and_all_policies_receive_clocks():
    args = parser().parse_args(["--candidate-revision", "HEAD", "--games", "1", "--max-steps", "3",
                               "--mode", "both", "--opponent", "research:cautious_defender"])
    report = evaluate(args)
    one, two = report["cells"]
    assert one["physics_config_sha256"] == two["physics_config_sha256"]
    assert one["config_sha256"] != two["config_sha256"]
    for cell in report["cells"]:
        for leg in cell["pairs"][0]["legs"]:
            assert all(leg["clock_injected"].values())
            assert leg["stats"]["candidate"]["reserved_decision_slots"] \
                == leg["stats"]["opponent"]["reserved_decision_slots"]


@pytest.mark.parametrize("mode", ["realtime", "lockstep"])
def test_telemetry_is_bounded_and_does_not_change_frozen_v3_trajectory(mode):
    bot, _ = opponent_factory("research:opportunistic_combat")
    config = SimConfig(mode=mode, max_steps=170)
    plain = play_game(bot, bot, config=config, seed=1101)
    observed = play_game(bot, bot, config=config, seed=1101, diagnostics=True)
    assert plain["trajectory_sha256"] == observed["trajectory_sha256"]
    assert plain["final_state_sha256"] == observed["final_state_sha256"]
    assert plain["result"] == observed["result"]
    diagnostic = observed["diagnostics"]
    assert len(diagnostic["snapshots"]) <= 13
    assert len(diagnostic["first_deaths"]) <= 12
    assert len(diagnostic["objective_events"]) <= 4
    assert diagnostic["snapshots"][-1]["step"] == observed["steps"]
    assert '"action_id"' not in json.dumps(diagnostic) and '"observation"' not in json.dumps(diagnostic)
    for camp, stats in diagnostic["teams"].items():
        damage = sum(v for k, v in stats["damage_dealt"].items() if k != "hero_to_hero" and k != "tower_to_hero")
        assert damage == pytest.approx(observed["result"]["outcome"]["score"][camp]["enemy_structure_damage"])
        assert stats["alive_hero_s"] + stats["dead_hero_s"] == pytest.approx(observed["elapsed_game_s"] * 5)


def test_arbitrary_factory_freezes_relative_and_agent_imports_without_global_patch(tmp_path):
    import builtins
    import sys
    original_import = builtins.__import__
    package = tmp_path / "research"
    package.mkdir()
    (package / "__init__.py").write_text("")
    (package / "helper.py").write_text("ACTION = 'macro_advance'\n")
    (package / "factory.py").write_text(
        "from .helper import ACTION\n"
        "def make_bot(seed=0, clock=None, config=None):\n"
        "    class Bot:\n"
        "        def decide(self, raw):\n"
        "            return {'seat': raw['seats'][0], 'macro': ACTION}, None\n"
        "    config['seen'].append(seed)\n"
        "    assert len(config['seen']) == 1\n"
        "    return Bot()\n")
    factory, info = frozen_import_factory("research.factory:make_bot", tmp_path)
    (package / "helper.py").write_text("ACTION = 'macro_retreat'\n")
    configured = configured_factory(factory, {"config": {"seen": []}})
    idle, _ = opponent_factory("idle")
    for seed in (1101, 1102):
        result = play_game(configured, idle, seed=seed, config=SimConfig(max_steps=2))
        assert result["stats"]["candidate"]["action_kind_counts"] == {"macro_advance": 12}
    assert builtins.__import__ is original_import
    assert "research.factory" not in sys.modules
    assert not source_unchanged(info)
    assert not (package / "__pycache__").exists()


def test_git_factory_snapshot_and_json_instance_configuration():
    root = Path(__file__).resolve().parents[2]
    factory, info = frozen_import_factory("agent.hok.policy:HokPolicy", root, "HEAD")
    assert info["source_kind"] == "git_snapshot"
    assert info["entrypoint"] == "agent.hok.policy:HokPolicy"
    assert source_unchanged(info)
    random_bot, _ = opponent_factory("random")
    result = play_game(factory, random_bot, config=SimConfig(max_steps=2))
    assert result["protocol_failure"] is None
    with pytest.raises(ValueError):
        configured_factory(factory, {"clock": 5})
    with pytest.raises(ValueError):
        configured_factory(factory, {"unsupported_option": True})


@pytest.mark.parametrize("action", [{"macro": "macro_advance"}, {"seat": [], "macro": "macro_advance"}])
def test_malformed_server_action_is_counted_even_with_order_churn_instrumentation(action):
    class Bad:
        def decide(self, raw):
            return action, None
    idle, _ = opponent_factory("idle")
    result = play_game(Bad, idle, config=SimConfig(max_steps=1), diagnostics=True)
    assert result["stats"]["candidate"]["invalid"] == 6
    assert result["protocol_failure"] is None


def test_frozen_factory_absolute_agent_import_is_not_the_live_module(tmp_path):
    import sys
    live = sys.modules.get("agent.hok.policy")
    package = tmp_path / "research"
    package.mkdir()
    (package / "__init__.py").write_text("")
    (package / "factory.py").write_text(
        "def make(seed=0, clock=None):\n"
        "    from agent.hok.policy import HokPolicy\n"
        "    return HokPolicy(clock=clock)\n")
    agent = tmp_path / "agent"
    agent.mkdir()
    (agent / "__init__.py").write_text("")
    hok = agent / "hok"
    hok.mkdir()
    (hok / "__init__.py").write_text("")
    policy = hok / "policy.py"
    policy.write_text("class HokPolicy:\n"
                      "    def __init__(self, clock): self.clock = clock\n"
                      "    def decide(self, raw):\n"
                      "        return {'seat': raw['seats'][0], 'macro': 'macro_retreat'}, None\n")
    factory, info = frozen_import_factory("research.factory:make", tmp_path)
    policy.write_text("raise AssertionError('the edited live source must not be imported')\n")
    idle, _ = opponent_factory("idle")
    result = play_game(factory, idle, config=SimConfig(max_steps=2))
    assert result["stats"]["candidate"]["action_kind_counts"] == {"macro_retreat": 12}
    assert sys.modules.get("agent.hok.policy") is live
    assert not source_unchanged(info)


def test_source_factory_can_be_a_partial_with_fresh_configuration(tmp_path):
    (tmp_path / "factory.py").write_text(
        "from functools import partial\n"
        "class Bot:\n"
        "    def __init__(self, macro, seed=0, clock=None): self.macro = macro\n"
        "    def decide(self, raw):\n"
        "        return {'seat': raw['seats'][0], 'macro': self.macro}, None\n"
        "make = partial(Bot, macro='macro_advance')\n")
    factory, info = frozen_import_factory("factory:make", tmp_path)
    assert info["factory"] == "partial"
    idle, _ = opponent_factory("idle")
    result = play_game(factory, idle, config=SimConfig(max_steps=2))
    assert result["stats"]["candidate"]["action_kind_counts"] == {"macro_advance": 12}


def test_raw_movement_is_not_reported_as_idle_occupancy():
    class Mover:
        def decide(self, raw):
            return {"seat": raw["seats"][0], "which_button": 2, "move_x": 15, "move_z": 8}, None
    idle, _ = opponent_factory("idle")
    result = play_game(Mover, idle, config=SimConfig(max_steps=4), diagnostics=True)
    team = result["diagnostics"]["teams"]["1"]
    assert team["raw_movement_hero_s"] == pytest.approx(0.8)
    assert team["idle_alive_hero_s"] == pytest.approx(3.2)


@pytest.mark.parametrize("profile", list(PROFILES))
@pytest.mark.parametrize("mode", ["realtime", "lockstep"])
def test_v4_neutral_bridge_preserves_v3_physical_trajectory(profile, mode):
    bot, _ = opponent_factory("research:opportunistic_combat")
    config = profile_config(profile, mode=mode, max_steps=130)
    v3 = play_game(bot, bot, config=config, seed=1101, diagnostics=True)
    v4 = play_game(bot, bot, config=config, seed=1101, diagnostics=True, sensitivity=SensitivityConfig())
    assert v3["trajectory_sha256"] == v4["trajectory_sha256"]
    assert v3["final_state_sha256"] == v4["final_state_sha256"]
    assert v3["result"] == v4["result"]
    assert v3["diagnostics"] == v4["diagnostics"]


@pytest.mark.parametrize("scale", [0, 0.25, 1])
def test_v4_skill_multiplier_affects_only_buildings_not_masks_or_hero_damage(scale):
    cfg = SimConfig(tower_damage=0)
    game = SensitivityGame(cfg, sensitivity=SensitivityConfig(scale, 1))
    reference = DiagnosticGame(cfg)
    assert game.view(1) == reference.view(1)
    hero = game.heroes[0]
    hero.x, hero.z = game.structures[200].x, 0
    assert game._skill_damage_against(100, hero) == 100
    assert not game.submit(1, "s0:macro_skill1", 0).get("error")
    game.tick()
    assert game.structures[200].hp == pytest.approx(cfg.tower_hp - cfg.skill_damage[0] * scale)
    assert hero.ready["macro_skill1"] == cfg.skill_cooldowns_s[0]  # even a zero-effect cast consumes cooldown


@pytest.mark.parametrize("scale", [0, 0.25, 1])
def test_v4_healing_multiplier_does_not_remove_full_hp_respawn(scale):
    cfg = SimConfig()
    game = SensitivityGame(cfg, sensitivity=SensitivityConfig(1, scale))
    game.heroes[0].hp = 1000
    game.heroes[1].hp, game.heroes[1].revive_at = 0, 0
    game.tick()
    assert game.heroes[0].hp == pytest.approx(1000 + cfg.hero_hp * cfg.base_heal_fraction_per_s * cfg.step_s * scale)
    assert game.heroes[1].hp == cfg.hero_hp


def test_v4_registration_is_fixed_and_separate_from_v3():
    assert len(SENSITIVITY_PROFILES) == 9
    assert SENSITIVITY_REGISTRATION_SHA256 == digest(SENSITIVITY_REGISTRATION)
    assert SENSITIVITY_REGISTRATION_SHA256 == "1cc51ff9998f7c652124707e52ac0494545ba10f1095684997c296778924a7fb"
    assert SENSITIVITY_REGISTRATION["excluded_selection_and_confirmation_seeds"] == [1201, 8101, 8102]
    with pytest.raises(ValueError):
        SensitivityConfig(0.5, 1)  # not a registered arm
    with pytest.raises(ValueError):
        SensitivityConfig(True, 1)
    args = parser().parse_args(["--games", "1", "--max-steps", "2", "--sensitivity", "skill-0_heal-0"])
    with pytest.raises(ValueError):
        evaluate(args)
    args.model = "v4"
    report = evaluate(args)
    assert report["model"] != report["base_model"]
    assert report["sensitivity_registration_sha256"] == SENSITIVITY_REGISTRATION_SHA256
    assert report["cells"][0]["sensitivity"] == {"building_skill_multiplier": 0.0, "base_healing_multiplier": 0.0}
    assert report["cells"][0]["treatment_sha256"] == SensitivityConfig(0, 0).treatment_hash


def test_legacy_sdk_list_adapter_is_thin_and_clock_metadata_is_explicit():
    from altruagent import LegalAction
    class Legacy:
        def __init__(self):
            self.errors = 0
        def decide(self, raw, legal_actions):
            assert all(isinstance(action, LegalAction) for action in legal_actions)
            return legal_actions[0], None
    adapter, info = adapt_policy_interface(Legacy, source_info(Legacy))
    assert info["interface_adapter"] == "raw_plus_sdk_legal_actions"
    assert info["native_clock_parameter"] is False
    assert "state_version" in info["clock_binding"]
    push, _ = opponent_factory("push")
    report = play_game(adapter, push, config=SimConfig(max_steps=2))
    assert report["protocol_failure"] is None
    assert report["native_policy_errors"] == {"candidate": 0, "opponent": 0}


def test_unsupported_interface_is_not_a_simulated_loss():
    class Unsupported:
        def decide(self, raw, unknown, required):
            return None, None
    with pytest.raises(PolicyInterfaceError, match="unsupported_decide_signature"):
        adapt_policy_interface(Unsupported, source_info(Unsupported))


def test_protected_seed_gate_fails_before_any_game_is_constructed(monkeypatch):
    import scripts.hok_eval as cli
    def forbidden(*args, **kwargs):
        raise AssertionError("a protected game must not start")
    monkeypatch.setattr(cli, "play_game", forbidden)
    for seed in (1201, 8101, 8102):
        args = parser().parse_args(["--seed", str(seed), "--games", "1"])
        with pytest.raises(ReservedSeedError):
            evaluate(args)
    args.authorize_reserved_with_final_sha = "{FINAL_SHA}"
    with pytest.raises(ReservedSeedError):
        evaluate(args)


def test_interface_check_is_metadata_only(monkeypatch):
    import scripts.hok_eval as cli
    def forbidden(*args, **kwargs):
        raise AssertionError("interface checks must not run matches")
    monkeypatch.setattr(cli, "play_game", forbidden)
    args = parser().parse_args(["--candidate-revision", "HEAD", "--check-interface"])
    result = interface_report(args)
    assert result["games"] == 0 and result["seed_used"] is None
    assert result["status"] == "interface_compatible_static_check"


def test_per_hero_metrics_separate_travel_from_stationary_no_gain_and_reset_on_life_changes():
    config = SimConfig(base_heal_fraction_per_s=0, max_steps=30)
    telemetry = DiagnosticTelemetry(config)
    game = DiagnosticGame(config)
    hero = game.heroes[0]
    hero.hp, hero.x, hero.z = 1000, -config.half_length + 3600, 0
    game.standing[0] = "macro_retreat"
    for _ in range(12):
        telemetry.before_tick(game)
        game.tick()
    row = telemetry.per_hero["0"]
    assert row["retreat_s"] == pytest.approx(2.4)
    assert row["no_hp_gain_retreat_s"] > row["stationary_no_gain_retreat_s"] > 0
    assert row["max_stationary_no_gain_retreat_s"] > 0
    old = row["max_stationary_no_gain_retreat_s"]
    hero.hp = 1100  # observed improvement resets the live streak
    telemetry.before_tick(game)
    assert telemetry._hero_streaks[0]["retreat"] == 0
    hero.hp, hero.deaths = 0, 1
    telemetry.before_tick(game)
    hero.hp = hero.max_hp
    telemetry.before_tick(game)
    assert telemetry._hero_streaks[0]["retreat"] == 0
    assert row["max_stationary_no_gain_retreat_s"] == old


def test_per_hero_metrics_do_not_change_policy_physics_or_inputs():
    bot, _ = opponent_factory("push")
    plain = play_game(bot, bot, config=SimConfig(max_steps=100), diagnostics=False)
    measured = play_game(bot, bot, config=SimConfig(max_steps=100), diagnostics=True)
    assert plain["trajectory_sha256"] == measured["trajectory_sha256"]
    assert set(measured["diagnostics"]["per_hero"]) == {str(s) for s in range(10)}
    assert "per_hero" not in DiagnosticGame().view(1)


def test_public_index_deduplicates_pairs_and_marks_correlated_units_without_private_paths():
    args = parser().parse_args(["--games", "1", "--max-steps", "2", "--mode", "both"])
    report = evaluate(args)
    index = public_archive_index([report, report])
    counts = index["counting"]
    assert counts["raw_leg_records"] == 8 and counts["unique_generated_legs"] == 4
    assert counts["duplicate_pairs_removed"] == 2
    assert counts["world_seeds"] == [0] and counts["shared_seed_opponent_families"] == 1
    assert counts["independent_real_games"] == 0
    text = json.dumps(index)
    assert "/tmp/" not in text and "/private/" not in text
    assert '"observation"' not in text and '"action_id"' not in text
    incompatible = {"status": "interface_incompatible", "interface_error": "unsupported_decide_signature",
                    "games": 0, "cells": [], "candidate_revision": "missing"}
    assert public_archive_index([incompatible])["counting"]["unique_generated_legs"] == 0


def test_final_plan_is_gated_metadata_and_never_executes_reserved_commands(monkeypatch):
    import scripts.hok_eval as cli
    monkeypatch.setattr(cli, "resolve_revision", lambda root, rev: {"fb421a2": "a" * 40,
                                                                 "503c36e": "b" * 40}[rev])
    monkeypatch.setattr(cli.subprocess, "run", lambda *a, **k: None)
    monkeypatch.setattr(cli, "candidate_revision_factory", lambda *a: (None, {"git_commit": "a" * 40}))
    monkeypatch.setattr(cli, "opponent_factory", lambda name, **kwargs: (None, {"name": name, "git_commit": "b" * 40}))
    plan = prepare_final_plan()
    assert plan["games_run"] == 0 and plan["autostart"] is False
    assert len(plan["commands"]) == 8 and plan["max_workers"] == 4
    for task in plan["commands"]:
        assert task["seed"] in (8101, 8102)
        assert "{FINAL_SHA}" in task["argv"]
        assert "--authorize-reserved-with-final-sha" in task["argv"]
